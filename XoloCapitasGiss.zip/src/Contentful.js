import * as contentful from 'contentful';

var Cliente = contentful.createClient({
    space: '257tb8oaug2e',
    accessToken: 'j7wb-3wZu5IDvbo3eWbCu8f8nh9OsAHzci-yXzt6Rvc'
});

export default Cliente

